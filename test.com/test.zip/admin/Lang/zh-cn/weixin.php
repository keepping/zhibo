<?php
return array(
	'MCONF_PLATFORM_STATUS_0'	=>	'否',
	'MCONF_PLATFORM_STATUS_1'	=>	'是',
);
?>