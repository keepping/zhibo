﻿using System;
using System.Collections.Generic;
using System.Text;
using JsonFx.Json;

namespace OpenFlashChart
{
    [Obsolete("use Area instead")]
    public class AreaHollow : AreaBase  
    {
       
       public AreaHollow()
       {
           //this.ChartType = "area_hollow";
       }
        
    }

    
}
