<?php
//过滤所有请求
class FilterStringBehavior extends Think
{
	public function run(){
		//代扩展的请求过滤
	}
}
?>