<?php

    class ContractModel extends CommonModel {
    	
    }

?>