<?php

class DealRoadshowCateModel extends CommonModel {
     
}
?>