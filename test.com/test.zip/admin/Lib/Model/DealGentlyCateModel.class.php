<?php

class DealGentlyCateModel extends CommonModel {
     
}
?>