<?php

class DealCreationSpaceCateModel extends CommonModel {
     
}
?>